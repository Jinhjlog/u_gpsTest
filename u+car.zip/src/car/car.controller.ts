import { Body, Controller, Get } from "@nestjs/common";
import { CarService } from './car.service';

@Controller('')
export class CarController {
  constructor(private readonly carService: CarService) {}

  @Get('car')
  test(@Body() data) {
    return this.carService.getCarArr(data);
  }
  /*
  @Get('interval')
  test2() {
    //this.carService.testInterval();
  }


  @Get('testMap')
  testMap(){
    return this.carService.testMap();
  }*/
}
